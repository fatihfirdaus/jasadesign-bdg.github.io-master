var twLSN = ['www.elvaro.us','elvaro.us','www.cektokokita.com','cektokokita.com','tampilgaya.net','www.tampilgaya.net','localhost'];
var redirectURL = 'https://www.seotemplate.web.id';
